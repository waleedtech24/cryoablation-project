﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CryoablationSoftware.Migrations
{
    /// <inheritdoc />
    public partial class procedurestables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Procedures_Patients_PatientId",
                table: "Procedures");

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureROI",
                table: "Procedures",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureEquipmentUsed",
                table: "Procedures",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureDuration",
                table: "Procedures",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "CreatedById",
                table: "Procedures",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ProcedureStatus",
                table: "Procedures",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "ProcedureClinicalReports",
                columns: table => new
                {
                    ProcedureClinicalReportId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcedureId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ClinicalReportId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LinkedById = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LinkedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcedureClinicalReports", x => x.ProcedureClinicalReportId);
                    table.ForeignKey(
                        name: "FK_ProcedureClinicalReports_AspNetUsers_LinkedById",
                        column: x => x.LinkedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProcedureClinicalReports_ClinicalReports_ClinicalReportId",
                        column: x => x.ClinicalReportId,
                        principalTable: "ClinicalReports",
                        principalColumn: "ClinicalReportId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProcedureClinicalReports_Procedures_ProcedureId",
                        column: x => x.ProcedureId,
                        principalTable: "Procedures",
                        principalColumn: "ProcedureId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProcedureItemAssignments",
                columns: table => new
                {
                    AssignmentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcedureId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ItemId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    QuantityAssigned = table.Column<int>(type: "int", nullable: false),
                    AssignmentReason = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AssignedById = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    AssignedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcedureItemAssignments", x => x.AssignmentId);
                    table.ForeignKey(
                        name: "FK_ProcedureItemAssignments_AspNetUsers_AssignedById",
                        column: x => x.AssignedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProcedureItemAssignments_Items_ItemId",
                        column: x => x.ItemId,
                        principalTable: "Items",
                        principalColumn: "ItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProcedureItemAssignments_Procedures_ProcedureId",
                        column: x => x.ProcedureId,
                        principalTable: "Procedures",
                        principalColumn: "ProcedureId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProcedureItemUsages",
                columns: table => new
                {
                    UsageId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcedureId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ItemId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    QuantityUsed = table.Column<int>(type: "int", nullable: false),
                    UsageDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsageNotes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordedById = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RecordedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcedureItemUsages", x => x.UsageId);
                    table.ForeignKey(
                        name: "FK_ProcedureItemUsages_AspNetUsers_RecordedById",
                        column: x => x.RecordedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProcedureItemUsages_Items_ItemId",
                        column: x => x.ItemId,
                        principalTable: "Items",
                        principalColumn: "ItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProcedureItemUsages_Procedures_ProcedureId",
                        column: x => x.ProcedureId,
                        principalTable: "Procedures",
                        principalColumn: "ProcedureId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Procedures_CreatedById",
                table: "Procedures",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureClinicalReports_ClinicalReportId",
                table: "ProcedureClinicalReports",
                column: "ClinicalReportId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureClinicalReports_LinkedById",
                table: "ProcedureClinicalReports",
                column: "LinkedById");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureClinicalReports_ProcedureId_ClinicalReportId",
                table: "ProcedureClinicalReports",
                columns: new[] { "ProcedureId", "ClinicalReportId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemAssignments_AssignedById",
                table: "ProcedureItemAssignments",
                column: "AssignedById");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemAssignments_ItemId",
                table: "ProcedureItemAssignments",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemAssignments_ProcedureId",
                table: "ProcedureItemAssignments",
                column: "ProcedureId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemUsages_ItemId",
                table: "ProcedureItemUsages",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemUsages_ProcedureId",
                table: "ProcedureItemUsages",
                column: "ProcedureId");

            migrationBuilder.CreateIndex(
                name: "IX_ProcedureItemUsages_RecordedById",
                table: "ProcedureItemUsages",
                column: "RecordedById");

            migrationBuilder.AddForeignKey(
                name: "FK_Procedures_AspNetUsers_CreatedById",
                table: "Procedures",
                column: "CreatedById",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Procedures_Patients_PatientId",
                table: "Procedures",
                column: "PatientId",
                principalTable: "Patients",
                principalColumn: "PatientId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Procedures_AspNetUsers_CreatedById",
                table: "Procedures");

            migrationBuilder.DropForeignKey(
                name: "FK_Procedures_Patients_PatientId",
                table: "Procedures");

            migrationBuilder.DropTable(
                name: "ProcedureClinicalReports");

            migrationBuilder.DropTable(
                name: "ProcedureItemAssignments");

            migrationBuilder.DropTable(
                name: "ProcedureItemUsages");

            migrationBuilder.DropIndex(
                name: "IX_Procedures_CreatedById",
                table: "Procedures");

            migrationBuilder.DropColumn(
                name: "CreatedById",
                table: "Procedures");

            migrationBuilder.DropColumn(
                name: "ProcedureStatus",
                table: "Procedures");

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureROI",
                table: "Procedures",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200);

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureEquipmentUsed",
                table: "Procedures",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProcedureDuration",
                table: "Procedures",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50);

            migrationBuilder.AddForeignKey(
                name: "FK_Procedures_Patients_PatientId",
                table: "Procedures",
                column: "PatientId",
                principalTable: "Patients",
                principalColumn: "PatientId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

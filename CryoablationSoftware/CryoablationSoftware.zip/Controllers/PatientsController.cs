﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CryoablationSoftware.Data;
using CryoablationSoftware.Models;
using CryoablationSoftware.ViewModel;
using System.Security.Claims;

namespace CryoablationSoftware.Controllers
{
    public class PatientsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;
        public PatientsController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET: Patients
        public async Task<IActionResult> Index(string searchTerm = "")
        {
            var patientsQuery = _context.Patients
                .Include(p => p.Procedures)
                .AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.ToLower();
                patientsQuery = patientsQuery.Where(p =>
                    p.PatientName.ToLower().Contains(searchTerm)
                    || p.PatientCNIC.Contains(searchTerm)
                    || p.PatientPhone.Contains(searchTerm)
                    || p.PatientCity.ToLower().Contains(searchTerm));
            }

            var patients = await patientsQuery
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();

            return View(patients);
        }

        // GET: Patients/Details/5
        public async Task<IActionResult> Details(Guid id)
        {
            var patient = await _context.Patients
                .Include(p => p.EmergencyContacts)
                .Include(p => p.ReferralInfos)
                .Include(p => p.Procedures)
                .Include(p => p.MedicalRecords)
                    .ThenInclude(mr => mr.ClinicalReports)
                .Include(p => p.MedicalRecords)
                    .ThenInclude(mr => mr.BoardApproval)
                .FirstOrDefaultAsync(p => p.PatientId == id);

            if (patient == null)
                return NotFound();

            return View(patient);
        }


        // GET: Patients/Create
        [HttpGet]
        public IActionResult Create()
        {
            // Tumhare ViewModel ke mutabiq sirf lists initialize karo
            var vm = new PatientCreateViewModel
            {
                EmergencyContacts = new List<EmergencyContactViewModel>(),
                ReferralInfos = new List<ReferralInfoViewModel>(),
                ClinicalReports = new List<ClinicalReportViewModel>(),
                MedicalRecordCancerType = new List<string>() // Yeh bhi JS ya view mein use hota
            };
            return View(vm);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PatientCreateViewModel model)
        {
            // 1. Server-side Model Validation
            if (!ModelState.IsValid)
            {
                return View(model); // Client error, form reload with error messages
            }

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userId))
            {
                ModelState.AddModelError("", "User not found, please login again.");
                return View(model);
            }
            // 2. UserID (CreatedById) — tumhare project me login user ka ID assign karo
           // var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
     //      var userId = "PASTE_KARO_APNI_USERID_YAHAN"; // Must exist in ApplicationUser table

            // BEGIN TRANSACTION
            using var tx = await _context.Database.BeginTransactionAsync();

            try
            {
                // 3. Patient Create (pehle Patient save karo)
                var patient = new Patient
                {
                    PatientName = model.PatientName,
                    PatientCNIC = model.PatientCNIC,
                    PatientDOB = model.PatientDOB,
                    PatientMRNumber = model.PatientMRNumber,
                    PatientPhone = model.PatientPhone,
                    PatientGender = model.PatientGender,
                    PatientAge = model.PatientAge,
                    PatientAddress = model.PatientAddress,
                    PatientCity = model.PatientCity,
                    PatientProvince = model.PatientProvince,
                    PatientInsuranceInfo = model.PatientInsuranceInfo,
                    PatientPaymentMode = model.PatientPaymentMode,
                  CreatedById = userId,

                   // CreatedById = userId, // Foreign key constraint!
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.Patients.Add(patient);
                await _context.SaveChangesAsync(); // PatientId mil jayega

                // 4. EmergencyContacts — PatientId set karo
                if (model.EmergencyContacts != null)
                {
                    foreach (var ecVm in model.EmergencyContacts)
                    {
                        var ec = new EmergencyContact
                        {
                            EmergencyContactName = ecVm.Name,
                            EmergencyContactCNIC = ecVm.CNIC,
                            EmergencyContactRelationship = ecVm.Relationship,
                            EmergencyContactPhone = ecVm.Phone,
                            EmergencyContactAddress = ecVm.Address,
                            EmergencyContactCity = ecVm.City,
                            EmergencyContactProvince = ecVm.Province,
                            PatientId = patient.PatientId, // Foreign key yahan!
                            CreatedAt = DateTime.UtcNow,
                            IsActive = true
                        };
                        _context.EmergencyContacts.Add(ec);
                    }
                    await _context.SaveChangesAsync();
                }

                // 5. ReferralInfos — PatientId set karo
                if (model.ReferralInfos != null)
                {
                    foreach (var rVm in model.ReferralInfos)
                    {
                        var refInfo = new ReferralInfo
                        {
                            ReferralHospitalName = rVm.HospitalName,
                            ReferralCity = rVm.City,
                            ReferralDoctorName = rVm.DoctorName,
                            ReferralDepartment = rVm.Department,
                            ReferralPhone = rVm.Phone,
                            ReferralEmail = rVm.Email,
                            PatientId = patient.PatientId,
                            CreatedAt = DateTime.UtcNow,
                            IsActive = true
                        };
                        _context.ReferralInfos.Add(refInfo);
                    }
                    await _context.SaveChangesAsync();
                }

                // 6. MedicalRecord — PatientId set karo, nullables ka dhyan
                var medRec = new MedicalRecord
                {
                    PatientId = patient.PatientId,
                    MedicalRecordCancerType = model.MedicalRecordCancerType != null ? string.Join(",", model.MedicalRecordCancerType) : null,
                    MedicalRecordCancerStage = model.MedicalRecordCancerStage,
                    MedicalRecordComorbidities = model.MedicalRecordComorbidities,
                    MedicalRecordTumorLocation = model.MedicalRecordTumorLocation,
                    MedicalRecordAllergies = model.MedicalRecordAllergies,
                    MedicalRecordClinicalHistory = model.MedicalRecordClinicalHistory,
           
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.MedicalRecords.Add(medRec);
                await _context.SaveChangesAsync();

                // 7. Clinical Reports — MedicalRecordId set karo
                if (model.ClinicalReports != null)
                {
                    foreach (var cVm in model.ClinicalReports)
                    {
                        var reportFilePath = ""; // Yahan file upload ka logic lagao
                        if (cVm.ReportFile != null && cVm.ReportFile.Length > 0)
                        {
                            var uploadFolder = Path.Combine(_env.WebRootPath, "uploads", "clinicalreports");
                            if (!Directory.Exists(uploadFolder))
                                Directory.CreateDirectory(uploadFolder);

                            var fileName = Guid.NewGuid() + Path.GetExtension(cVm.ReportFile.FileName);
                            var path = Path.Combine(uploadFolder, fileName);
                            using (var stream = new FileStream(path, FileMode.Create))
                            {
                                await cVm.ReportFile.CopyToAsync(stream);
                            }
                            reportFilePath = "/uploads/clinicalreports/" + fileName;
                        }

                        var cr = new ClinicalReport
                        {
                            MedicalRecordId = medRec.MedicalRecordId,
                            ReportType = cVm.ReportType,
                            ReportFilePath = reportFilePath,
                            CreatedAt = DateTime.UtcNow,
                            IsActive = true
                        };
                        _context.ClinicalReports.Add(cr);
                    }
                    await _context.SaveChangesAsync();
                }

                // 8. Board Approval — MedicalRecordId set karo
                var boardApprovalFilePath = "";
                if (model.BoardApprovalAttachment != null && model.BoardApprovalAttachment.Length > 0)
                {
                    var uploadFolder = Path.Combine(_env.WebRootPath, "uploads", "boardapprovals");
                    if (!Directory.Exists(uploadFolder))
                        Directory.CreateDirectory(uploadFolder);

                    var fileName = Guid.NewGuid() + Path.GetExtension(model.BoardApprovalAttachment.FileName);
                    var path = Path.Combine(uploadFolder, fileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await model.BoardApprovalAttachment.CopyToAsync(stream);
                    }
                    boardApprovalFilePath = "/uploads/boardapprovals/" + fileName;
                }

                var boardApproval = new BoardApproval
                {
                    MedicalRecordId = medRec.MedicalRecordId,
                    BoardApprovalDate = model.BoardApprovalDate ?? DateTime.UtcNow,
                    BoardApprovalDecision = model.BoardApprovalDecision ?? false,
                    BoardApprovalLetterNumber = model.BoardApprovalLetterNumber,
                    BoardApprovalAttachmentPath = boardApprovalFilePath,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };
                _context.BoardApprovals.Add(boardApproval);
                await _context.SaveChangesAsync();

                // 9. Procedure — PatientId set karo
                var procedure = new Procedure
                {
                    PatientId = patient.PatientId,
                    ProcedureDate = model.ProcedureDate ?? DateTime.UtcNow,
                    ProcedureDuration = model.ProcedureDuration,
                    ProcedureROI = model.ProcedureROI,
                    ProcedureRemarks = model.ProcedureRemarks,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true,
                    CreatedById = userId
                };
                _context.Procedures.Add(procedure);
                await _context.SaveChangesAsync();

                // Commit transaction
                await tx.CommitAsync();

                // Success
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                ModelState.AddModelError("", ex.InnerException?.Message ?? ex.Message);
                return View(model); // Stay on form page with error
            }
        }


        // GET: Patients/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patient = await _context.Patients.FindAsync(id);
            if (patient == null)
            {
                return NotFound();
            }
            ViewData["CreatedById"] = new SelectList(_context.Set<ApplicationUser>(), "Id", "FullName", patient.CreatedById);
            return View(patient);
        }

        // POST: Patients/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("PatientId,PatientName,PatientDOB,PatientCNIC,PatientMRNumber,PatientPhone,PatientGender,PatientAge,PatientAddress,PatientCity,PatientProvince,PatientInsuranceInfo,PatientPaymentMode,CreatedById,CreatedAt,IsActive")] Patient patient)
        {
            if (id != patient.PatientId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(patient);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PatientExists(patient.PatientId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CreatedById"] = new SelectList(_context.Set<ApplicationUser>(), "Id", "FullName", patient.CreatedById);
            return View(patient);
        }

        // GET: Patients/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patient = await _context.Patients
                .Include(p => p.CreatedBy)
                .FirstOrDefaultAsync(m => m.PatientId == id);
            if (patient == null)
            {
                return NotFound();
            }

            return View(patient);
        }

        // POST: Patients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if (patient != null)
            {
                _context.Patients.Remove(patient);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PatientExists(Guid id)
        {
            return _context.Patients.Any(e => e.PatientId == id);
        }
    }
}

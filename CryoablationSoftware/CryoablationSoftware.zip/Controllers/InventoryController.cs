﻿using CryoablationSoftware.Services;
using CryoablationSoftware.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CryoablationSoftware.Controllers
{
    public class InventoryController : Controller
    {
        private readonly IInventoryService _inventoryService;
        private readonly UserManager<IdentityUser> _userManager;

        public InventoryController(IInventoryService inventoryService, UserManager<IdentityUser> userManager)
        {
            _inventoryService = inventoryService;
            _userManager = userManager;
        }
        #region Dashboard

        public async Task<IActionResult> Index()
        {
            var dashboardData = await _inventoryService.GetDashboardDataAsync();
            return View(dashboardData);
        }

        #endregion

        #region Items Management

        public async Task<IActionResult> Items()
        {
            var items = await _inventoryService.GetAllItemsAsync();
            return View(items);
        }

        [HttpGet]
        public async Task<IActionResult> CreateItem()
        {
            await LoadItemDropdowns();
            return View(new ItemCreateViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateItem(ItemCreateViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if item code is unique
                var isUnique = await _inventoryService.IsItemCodeUniqueAsync(model.ItemCode);
                if (!isUnique)
                {
                    ModelState.AddModelError("ItemCode", "Item Code already exists");
                    await LoadItemDropdowns();
                    return View(model);
                }

                var userId = _userManager.GetUserId(User);
                var result = await _inventoryService.CreateItemAsync(model, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Item created successfully";
                    return RedirectToAction(nameof(Items));
                }
                else
                {
                    TempData["ErrorMessage"] = "Error creating item";
                }
            }

            await LoadItemDropdowns();
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> EditItem(Guid id)
        {
            var item = await _inventoryService.GetItemByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }

            var model = new ItemEditViewModel
            {
                ItemId = item.ItemId,
                ItemName = item.ItemName,
                ItemCode = item.ItemCode,
                Category = item.Category,
                Unit = item.Unit,
                ReorderLevel = item.ReorderLevel,
                Description = item.Description,
                IsActive = item.IsActive
            };

            await LoadItemDropdowns();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditItem(ItemEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if item code is unique (excluding current item)
                var isUnique = await _inventoryService.IsItemCodeUniqueAsync(model.ItemCode, model.ItemId);
                if (!isUnique)
                {
                    ModelState.AddModelError("ItemCode", "Item Code already exists");
                    await LoadItemDropdowns();
                    return View(model);
                }

                var result = await _inventoryService.UpdateItemAsync(model);

                if (result)
                {
                    TempData["SuccessMessage"] = "Item updated successfully";
                    return RedirectToAction(nameof(Items));
                }
                else
                {
                    TempData["ErrorMessage"] = "Error updating item";
                }
            }

            await LoadItemDropdowns();
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> ItemDetails(Guid id)
        {
            var item = await _inventoryService.GetItemByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }

            ViewBag.CurrentStock = await _inventoryService.GetCurrentStockAsync(id);
            ViewBag.StockHistory = await _inventoryService.GetStockHistoryAsync(id);
            ViewBag.UsageHistory = await _inventoryService.GetUsageHistoryAsync(id);

            return View(item);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteItem(Guid id)
        {
            var result = await _inventoryService.DeleteItemAsync(id);

            if (result)
            {
                TempData["SuccessMessage"] = "Item deleted successfully";
            }
            else
            {
                TempData["ErrorMessage"] = "Error deleting item";
            }

            return RedirectToAction(nameof(Items));
        }

        #endregion

        #region Stock Management

        [HttpGet]
        public async Task<IActionResult> ReceiveStock()
        {
            await LoadStockDropdowns();
            return View(new StockReceiveViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReceiveStock(StockReceiveViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var result = await _inventoryService.ReceiveStockAsync(model, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Stock received successfully";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["ErrorMessage"] = "Error receiving stock";
                }
            }

            await LoadStockDropdowns();
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> IssueStock()
        {
            await LoadIssueDropdowns();
            return View(new StockIssueViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IssueStock(StockIssueViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var result = await _inventoryService.IssueStockAsync(model, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Stock issued successfully";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["ErrorMessage"] = "Insufficient stock or error issuing stock";
                }
            }

            await LoadIssueDropdowns();
            return View(model);
        }

        [HttpGet]
        public async Task<JsonResult> GetCurrentStock(Guid itemId)
        {
            var currentStock = await _inventoryService.GetCurrentStockAsync(itemId);
            return Json(new { stock = currentStock });
        }

        [HttpGet]
        public async Task<JsonResult> GetItemDetails(Guid itemId)
        {
            var item = await _inventoryService.GetItemByIdAsync(itemId);
            var currentStock = await _inventoryService.GetCurrentStockAsync(itemId);

            return Json(new
            {
                itemName = item?.ItemName,
                unit = item?.Unit,
                currentStock = currentStock
            });
        }

        #endregion

        #region Suppliers Management

        //public async Task<IActionResult> Suppliers()
        //{
        //    var suppliers = await _inventoryService.GetAllSuppliersAsync();
        //    return View(suppliers);
        //}

        //[HttpGet]
        //public IActionResult CreateSupplier()
        //{
        //    return View(new SupplierCreateViewModel());
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> CreateSupplier(SupplierCreateViewModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var result = await _inventoryService.CreateSupplierAsync(model);

        //        if (result)
        //        {
        //            TempData["SuccessMessage"] = "Supplier created successfully";
        //            return RedirectToAction(nameof(Suppliers));
        //        }
        //        else
        //        {
        //            TempData["ErrorMessage"] = "Error creating supplier";
        //        }
        //    }

        //    return View(model);
        //}

        //[HttpGet]
        //public async Task<IActionResult> SupplierDetails(Guid id)
        //{
        //    var supplier = await _inventoryService.GetSupplierByIdAsync(id);
        //    if (supplier == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(supplier);
        //}

        #endregion

        #region Reports

        public async Task<IActionResult> StockReport()
        {
            var reportData = await _inventoryService.GetStockReportAsync();
            return View(reportData);
        }

        public async Task<IActionResult> LowStockReport()
        {
            var lowStockItems = await _inventoryService.GetLowStockItemsAsync();
            return View(lowStockItems);
        }

        #endregion

        #region Private Helper Methods

        private async Task LoadItemDropdowns()
        {
            var categories = await _inventoryService.GetCategoriesAsync();
            var units = await _inventoryService.GetUnitsAsync();

            ViewBag.Categories = categories.Any()
                ? categories.ToList()
                : new List<string> { "Consumables", "Equipment", "Medicines", "Supplies" };

            ViewBag.Units = units.Any()
                ? units.ToList()
                : new List<string> { "Pieces", "Box", "Pack", "Liters", "KG", "Meters" };
        }

        private async Task LoadStockDropdowns()
        {
            var items = await _inventoryService.GetAllItemsAsync();
           // var suppliers = await _inventoryService.GetAllSuppliersAsync();

            ViewBag.Items = items.Select(i => new {
                Value = i.ItemId,
                Text = $"{i.ItemName} ({i.ItemCode})"
            }).ToList();

            //ViewBag.Suppliers = suppliers.Select(s => new {
            //    Value = s.SupplierId,
            //    Text = s.SupplierName
            //}).ToList();
        }

        private async Task LoadIssueDropdowns()
        {
            var items = await _inventoryService.GetAllItemsAsync();

            ViewBag.Items = items.Select(i => new {
                Value = i.ItemId,
                Text = $"{i.ItemName} ({i.ItemCode})"
            }).ToList();

            ViewBag.UsageReasons = new List<string>
            {
                "Procedure",
                "Maintenance",
                "Damaged",
                "Expired",
                "Training",
                "Other"
            };

            // Load patients for dropdown (optional - if needed)
            // You can implement this based on your Patient service
        }

        #endregion

    }
}

﻿using CryoablationSoftware.Constants;
using CryoablationSoftware.Services;
using CryoablationSoftware.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CryoablationSoftware.Controllers
{
    public class ProcedureController : Controller
    {
        private readonly IProcedureService _procedureService;
        private readonly UserManager<IdentityUser> _userManager;

        public ProcedureController(IProcedureService procedureService, UserManager<IdentityUser> userManager)
        {
            _procedureService = procedureService;
            _userManager = userManager;
        }

        #region Dashboard & Main Views

        public async Task<IActionResult> Index()
        {
            var dashboardData = await _procedureService.GetDashboardDataAsync();
            return View(dashboardData);
        }

        public async Task<IActionResult> Procedures()
        {
            var procedures = await _procedureService.GetAllProceduresAsync();
            return View(procedures);
        }

        [HttpGet]
        public async Task<IActionResult> Details(Guid id)
        {
            var procedure = await _procedureService.GetProcedureDetailsAsync(id);
            if (procedure == null)
            {
                return NotFound();
            }

            return View(procedure);
        }

        #endregion

        #region Create Procedure

        [HttpGet]
        public async Task<IActionResult> Create(Guid? patientId)
        {
            await LoadCreateViewData();

            var model = new ProcedureCreateViewModel();

            // Set default date to tomorrow at 9 AM if not specified
            model.ProcedureDate = DateTime.Now.Date.AddDays(1).AddHours(9);
            model.ProcedureStatus = "Scheduled"; // Set default status

            if (patientId.HasValue)
            {
                model.PatientId = patientId.Value;
                // Load patient name for display
                var patients = await _procedureService.GetActivePatientsAsync();
                var patient = patients.FirstOrDefault(p => p.PatientId == patientId.Value);
                model.PatientName = patient?.PatientName;
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProcedureCreateViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var result = await _procedureService.CreateProcedureAsync(model, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Procedure created successfully";
                    return RedirectToAction(nameof(Procedures));
                }
                else
                {
                    TempData["ErrorMessage"] = "Error creating procedure. Please check item availability.";
                }
            }
            else
            {
                // Add detailed error messages
                TempData["ErrorMessage"] = "Please correct the errors below and try again.";
            }

            // IMPORTANT: Reload ViewBag data when returning to view with errors
            await LoadCreateViewData();

            // Ensure patient name is loaded for display even on error
            if (model.PatientId != Guid.Empty)
            {
                var patients = await _procedureService.GetActivePatientsAsync();
                var patient = patients.FirstOrDefault(p => p.PatientId == model.PatientId);
                model.PatientName = patient?.PatientName;
            }

            return View(model);
        }
        #endregion

        #region Edit Procedure

        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            var procedure = await _procedureService.GetProcedureByIdAsync(id);
            if (procedure == null)
            {
                return NotFound();
            }

            var model = new ProcedureEditViewModel
            {
                ProcedureId = procedure.ProcedureId,
                PatientId = procedure.PatientId,
                PatientName = procedure.Patient?.PatientName,
                ProcedureDate = procedure.ProcedureDate,
                ProcedureROI = procedure.ProcedureROI,
                ProcedureDuration = procedure.ProcedureDuration,
                ProcedureEquipmentUsed = procedure.ProcedureEquipmentUsed,
                ProcedureRemarks = procedure.ProcedureRemarks,
                ProcedureStatus = procedure.ProcedureStatus,
                ProcedureNextDate = procedure.ProcedureNextDate,
                PreviousProcedureId = procedure.PreviousProcedureId,
                IsActive = procedure.IsActive
            };

            await LoadEditViewData();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProcedureEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _procedureService.UpdateProcedureAsync(model);

                if (result)
                {
                    TempData["SuccessMessage"] = "Procedure updated successfully";
                    return RedirectToAction(nameof(Details), new { id = model.ProcedureId });
                }
                else
                {
                    TempData["ErrorMessage"] = "Error updating procedure";
                }
            }

            await LoadEditViewData();
            return View(model);
        }

        #endregion

        #region Delete Procedure

        [HttpPost]
        public async Task<IActionResult> Delete(Guid id)
        {
            var result = await _procedureService.DeleteProcedureAsync(id);

            if (result)
            {
                TempData["SuccessMessage"] = "Procedure deleted successfully";
            }
            else
            {
                TempData["ErrorMessage"] = "Error deleting procedure";
            }

            return RedirectToAction(nameof(Procedures));
        }

        #endregion

        #region Item Assignment

        [HttpGet]
        public async Task<IActionResult> AssignItems(Guid id)
        {
            var procedure = await _procedureService.GetProcedureByIdAsync(id);
            if (procedure == null)
            {
                return NotFound();
            }

            var items = await _procedureService.GetAvailableItemsAsync();
            ViewBag.AvailableItems = items.Select(i => new {
                Value = i.ItemId,
                Text = $"{i.ItemName} ({i.ItemCode})",
                Unit = i.Unit
            }).ToList();

            ViewBag.ProcedureId = id;
            ViewBag.PatientName = procedure.Patient?.PatientName;
            ViewBag.ProcedureROI = procedure.ProcedureROI;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignItem(Guid procedureId, Guid itemId, int quantity, string reason, string? notes)
        {
            var userId = _userManager.GetUserId(User);
            var result = await _procedureService.AssignItemToProcedureAsync(procedureId, itemId, quantity, reason, notes, userId);

            if (result)
            {
                TempData["SuccessMessage"] = "Item assigned successfully";
            }
            else
            {
                TempData["ErrorMessage"] = "Error assigning item";
            }

            return RedirectToAction(nameof(Details), new { id = procedureId });
        }

        [HttpPost]
        public async Task<IActionResult> RemoveAssignment(Guid assignmentId, Guid procedureId)
        {
            var result = await _procedureService.RemoveItemAssignmentAsync(assignmentId);

            if (result)
            {
                TempData["SuccessMessage"] = "Item assignment removed successfully";
            }
            else
            {
                TempData["ErrorMessage"] = "Cannot remove assignment - items may have been used";
            }

            return RedirectToAction(nameof(Details), new { id = procedureId });
        }

        #endregion

        #region Item Usage

        [HttpGet]
        public async Task<IActionResult> RecordUsage(Guid procedureId, Guid? itemId)
        {
            var procedure = await _procedureService.GetProcedureByIdAsync(procedureId);
            if (procedure == null)
            {
                return NotFound();
            }

            var itemSummaries = await _procedureService.GetProcedureItemSummaryAsync(procedureId);

            var model = new ProcedureItemUsageViewModel
            {
                ProcedureId = procedureId,
                PatientName = procedure.Patient?.PatientName,
                ProcedureROI = procedure.ProcedureROI,
                ProcedureDate = procedure.ProcedureDate
            };

            if (itemId.HasValue)
            {
                // FIXED: Changed 'is' to 'item' in lambda expression
                var itemSummary = itemSummaries.FirstOrDefault(item => item.ItemId == itemId.Value);
                if (itemSummary != null)
                {
                    model.ItemId = itemId.Value;
                    model.ItemName = itemSummary.ItemName;
                    model.ItemCode = itemSummary.ItemCode;
                    model.Unit = itemSummary.Unit;
                    model.QuantityAssigned = itemSummary.QuantityAssigned;
                    model.PreviouslyUsed = itemSummary.QuantityUsed;
                }
            }

            // FIXED: Changed 'is' to 'item' in lambda expressions
            ViewBag.AssignedItems = itemSummaries.Where(item => item.RemainingQuantity > 0).Select(item => new {
                Value = item.ItemId,
                Text = $"{item.ItemName} ({item.ItemCode}) - Remaining: {item.RemainingQuantity} {item.Unit}",
                QuantityAssigned = item.QuantityAssigned,
                PreviouslyUsed = item.QuantityUsed,
                Unit = item.Unit,
                ItemName = item.ItemName,
                ItemCode = item.ItemCode
            }).ToList();

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RecordUsage(ProcedureItemUsageViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var result = await _procedureService.RecordItemUsageAsync(model, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Item usage recorded successfully";
                    return RedirectToAction(nameof(Details), new { id = model.ProcedureId });
                }
                else
                {
                    TempData["ErrorMessage"] = "Error recording usage - check stock availability or assignment limits";
                }
            }

            // Reload view data if validation fails
            var procedure = await _procedureService.GetProcedureByIdAsync(model.ProcedureId);
            var itemSummaries = await _procedureService.GetProcedureItemSummaryAsync(model.ProcedureId);

            model.PatientName = procedure?.Patient?.PatientName;
            model.ProcedureROI = procedure?.ProcedureROI;
            model.ProcedureDate = procedure?.ProcedureDate ?? DateTime.MinValue;

            // FIXED: Changed 'is' to 'item' in lambda expressions
            ViewBag.AssignedItems = itemSummaries.Where(item => item.RemainingQuantity > 0).Select(item => new {
                Value = item.ItemId,
                Text = $"{item.ItemName} ({item.ItemCode}) - Remaining: {item.RemainingQuantity} {item.Unit}",
                QuantityAssigned = item.QuantityAssigned,
                PreviouslyUsed = item.QuantityUsed,
                Unit = item.Unit,
                ItemName = item.ItemName,
                ItemCode = item.ItemCode
            }).ToList();

            return View(model);
        }

        #endregion

        #region Clinical Reports

        [HttpGet]
        public async Task<IActionResult> LinkReport(Guid procedureId)
        {
            var procedure = await _procedureService.GetProcedureByIdAsync(procedureId);
            if (procedure == null)
            {
                return NotFound();
            }

            var availableReports = await _procedureService.GetAvailableClinicalReportsAsync(procedure.PatientId, procedureId);

            var model = new AddClinicalReportViewModel
            {
                ProcedureId = procedureId,
                PatientName = procedure.Patient?.PatientName,
                ProcedureROI = procedure.ProcedureROI,
                ProcedureDate = procedure.ProcedureDate,
                AvailableReports = availableReports
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LinkReport(AddClinicalReportViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = _userManager.GetUserId(User);
                var result = await _procedureService.LinkClinicalReportAsync(model.ProcedureId, model.ClinicalReportId, userId);

                if (result)
                {
                    TempData["SuccessMessage"] = "Clinical report linked successfully";
                    return RedirectToAction(nameof(Details), new { id = model.ProcedureId });
                }
                else
                {
                    TempData["ErrorMessage"] = "Error linking report - may already be linked";
                }
            }

            // Reload available reports
            var procedure = await _procedureService.GetProcedureByIdAsync(model.ProcedureId);
            if (procedure != null)
            {
                model.AvailableReports = await _procedureService.GetAvailableClinicalReportsAsync(procedure.PatientId, model.ProcedureId);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> UnlinkReport(Guid procedureId, Guid clinicalReportId)
        {
            var result = await _procedureService.UnlinkClinicalReportAsync(procedureId, clinicalReportId);

            if (result)
            {
                TempData["SuccessMessage"] = "Clinical report unlinked successfully";
            }
            else
            {
                TempData["ErrorMessage"] = "Error unlinking report";
            }

            return RedirectToAction(nameof(Details), new { id = procedureId });
        }

        #endregion

        #region Filter Views

        public async Task<IActionResult> ByPatient(Guid patientId)
        {
            var procedures = await _procedureService.GetProceduresByPatientAsync(patientId);

            var patients = await _procedureService.GetActivePatientsAsync();
            var patient = patients.FirstOrDefault(p => p.PatientId == patientId);
            ViewBag.PatientName = patient?.PatientName;
            ViewBag.PatientId = patientId;

            return View("ProceduresByFilter", procedures);
        }

        public async Task<IActionResult> ByStatus(string status)
        {
            var procedures = await _procedureService.GetProceduresByStatusAsync(status);
            ViewBag.FilterTitle = $"Procedures - {status}";
            ViewBag.FilterValue = status;

            return View("ProceduresByFilter", procedures);
        }

        #endregion

        #region AJAX Methods

        [HttpGet]
        public async Task<JsonResult> GetItemStock(Guid itemId)
        {
            var stock = await _procedureService.GetAvailableStockAsync(itemId);
            return Json(new { stock = stock });
        }

        [HttpGet]
        public async Task<JsonResult> GetPatientDetails(Guid patientId)
        {
            try
            {
                var patients = await _procedureService.GetActivePatientsAsync();
                var patient = patients.FirstOrDefault(p => p.PatientId == patientId);

                if (patient != null)
                {
                    return Json(new
                    {
                        patientName = patient.PatientName,
                        mrNumber = patient.PatientMRNumber,
                        phone = patient.PatientPhone,
                        age = patient.PatientAge,
                        gender = patient.PatientGender
                    });
                }

                return Json(new { error = "Patient not found" });
            }
            catch (Exception ex)
            {
                return Json(new { error = "Error loading patient details" });
            }
        }


        [HttpGet]
        public async Task<JsonResult> GetItemAssignmentInfo(Guid procedureId, Guid itemId)
        {
            var itemSummaries = await _procedureService.GetProcedureItemSummaryAsync(procedureId);
            // FIXED: Changed 'is' to 'item' in lambda expression
            var itemSummary = itemSummaries.FirstOrDefault(item => item.ItemId == itemId);

            if (itemSummary != null)
            {
                return Json(new
                {
                    itemName = itemSummary.ItemName,
                    itemCode = itemSummary.ItemCode,
                    unit = itemSummary.Unit,
                    quantityAssigned = itemSummary.QuantityAssigned,
                    quantityUsed = itemSummary.QuantityUsed,
                    remainingQuantity = itemSummary.RemainingQuantity
                });
            }

            return Json(new { error = "Item not found" });
        }

        #endregion

        #region Private Helper Methods

        private async Task LoadCreateViewData()
        {
            try
            {
                var patients = await _procedureService.GetActivePatientsAsync();
                var items = await _procedureService.GetAvailableItemsAsync();

                ViewBag.Patients = patients.Select(p => new {
                    Value = p.PatientId,
                    Text = $"{p.PatientName} ({p.PatientMRNumber})"
                }).ToList();

                ViewBag.Items = items.Select(i => new {
                    Value = i.ItemId,
                    Text = $"{i.ItemName} ({i.ItemCode})",
                    Unit = i.Unit
                }).ToList();

                ViewBag.ProcedureStatuses = new List<string> { "Scheduled", "In-Progress", "Completed", "Cancelled" };
            }
            catch (Exception ex)
            {
                // Log error and provide empty lists to prevent view errors
                ViewBag.Patients = new List<dynamic>();
                ViewBag.Items = new List<dynamic>();
                ViewBag.ProcedureStatuses = new List<string> { "Scheduled" };

                TempData["ErrorMessage"] = "Error loading form data. Please try again.";
            }
        }

        private async Task LoadEditViewData()
        {
            var patients = await _procedureService.GetActivePatientsAsync();

            ViewBag.Patients = patients.Select(p => new {
                Value = p.PatientId,
                Text = $"{p.PatientName} ({p.PatientMRNumber})"
            }).ToList();

            ViewBag.ProcedureStatuses = ProcedureStatus.GetAllStatuses();
        }

        #endregion




        #region Status Management

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeStatus(Guid procedureId, string newStatus)
        {
            try
            {
                // If completing procedure, redirect to completion form
                if (newStatus == "Completed")
                {
                    return RedirectToAction(nameof(CompleteProcedure), new { id = procedureId });
                }

                var procedure = await _procedureService.GetProcedureByIdAsync(procedureId);
                if (procedure == null)
                {
                    TempData["ErrorMessage"] = "Procedure not found";
                    return RedirectToAction(nameof(Procedures));
                }

                var editModel = new ProcedureEditViewModel
                {
                    ProcedureId = procedure.ProcedureId,
                    PatientId = procedure.PatientId,
                    ProcedureDate = procedure.ProcedureDate,
                    ProcedureROI = procedure.ProcedureROI,
                    ProcedureDuration = procedure.ProcedureDuration,
                    ProcedureEquipmentUsed = procedure.ProcedureEquipmentUsed,
                    ProcedureRemarks = procedure.ProcedureRemarks,
                    ProcedureStatus = newStatus, // Update status
                    ProcedureNextDate = procedure.ProcedureNextDate,
                    PreviousProcedureId = procedure.PreviousProcedureId,
                    IsActive = procedure.IsActive
                };

                var result = await _procedureService.UpdateProcedureAsync(editModel);

                if (result)
                {
                    TempData["SuccessMessage"] = $"Procedure status changed to {newStatus} successfully";
                }
                else
                {
                    TempData["ErrorMessage"] = "Error changing procedure status";
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error changing procedure status";
            }

            return RedirectToAction(nameof(Details), new { id = procedureId });
        }

        [HttpGet]
        public async Task<IActionResult> CompleteProcedure(Guid id)
        {
            var procedure = await _procedureService.GetProcedureByIdAsync(id);
            if (procedure == null)
            {
                return NotFound();
            }

            var model = new ProcedureCompletionViewModel
            {
                ProcedureId = id,
                PatientName = procedure.Patient?.PatientName,
                ProcedureROI = procedure.ProcedureROI,
                ProcedureDate = procedure.ProcedureDate,
                DischargeDate = DateTime.Now.Date,
                NextProcedureDate = procedure.ProcedureNextDate
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompleteProcedure(ProcedureCompletionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var procedure = await _procedureService.GetProcedureByIdAsync(model.ProcedureId);
                if (procedure == null)
                {
                    return NotFound();
                }

                // Update procedure with completion details
                var editModel = new ProcedureEditViewModel
                {
                    ProcedureId = procedure.ProcedureId,
                    PatientId = procedure.PatientId,
                    ProcedureDate = procedure.ProcedureDate,
                    ProcedureROI = procedure.ProcedureROI,
                    ProcedureDuration = procedure.ProcedureDuration,
                    ProcedureEquipmentUsed = procedure.ProcedureEquipmentUsed,
                    ProcedureRemarks = $"{procedure.ProcedureRemarks}\n\n--- COMPLETION DETAILS ---\nIR Consultant Remarks: {model.IRConsultantRemarks}\nDischarge Date: {model.DischargeDate?.ToString("dd/MM/yyyy")}\nCompletion Notes: {model.CompletionNotes}",
                    ProcedureStatus = "Completed",
                    ProcedureNextDate = model.NextProcedureDate,
                    PreviousProcedureId = procedure.PreviousProcedureId,
                    IsActive = procedure.IsActive
                };

                var result = await _procedureService.UpdateProcedureAsync(editModel);

                if (result)
                {
                    TempData["SuccessMessage"] = "Procedure completed successfully";
                    return RedirectToAction(nameof(PrintSummary), new { id = model.ProcedureId });
                }
                else
                {
                    TempData["ErrorMessage"] = "Error completing procedure";
                }
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> PrintSummary(Guid id)
        {
            var procedure = await _procedureService.GetProcedureDetailsAsync(id);
            if (procedure == null)
            {
                return NotFound();
            }

            return View(procedure);
        }

        #endregion

    }
}

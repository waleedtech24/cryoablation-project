﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace CryoablationSoftware.Models
{
    public class Procedure
    {
        [Key]
        public Guid ProcedureId { get; set; }

        [ForeignKey("Patient")]
        public Guid PatientId { get; set; }
        public Patient Patient { get; set; }

        [ForeignKey("CreatedBy")]
        public string CreatedById { get; set; }
        public IdentityUser CreatedBy { get; set; }

        // Procedure Details
        public DateTime ProcedureDate { get; set; }
        public string ProcedureROI { get; set; } // Region of Interest
        public string ProcedureDuration { get; set; }
        public string? ProcedureEquipmentUsed { get; set; }
        public string? ProcedureRemarks { get; set; }

        // Status & Scheduling
        public string ProcedureStatus { get; set; } = "Scheduled";
        // Values: Scheduled, In-Progress, Completed, Cancelled
        public DateTime? ProcedureNextDate { get; set; }
        public Guid? PreviousProcedureId { get; set; }

        // Audit
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true;

        // Navigation Properties
        public ICollection<ProcedureItemAssignment> ItemAssignments { get; set; }
        public ICollection<ProcedureItemUsage> ItemUsages { get; set; }
        public ICollection<ProcedureClinicalReport> ClinicalReports { get; set; }
    }
}

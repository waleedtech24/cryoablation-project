﻿using CryoablationSoftware.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;

namespace CryoablationSoftware.ViewModel
{
    public class PatientCreateViewModel
    {
        // Patient Fields
        public string PatientName { get; set; }
        public string PatientCNIC { get; set; }
        public DateTime? PatientDOB { get; set; }
        public string PatientMRNumber { get; set; }
        public string PatientPhone { get; set; }
        public string PatientGender { get; set; }
        public int PatientAge { get; set; }
        public string PatientAddress { get; set; }
        public string PatientCity { get; set; }
        public string PatientProvince { get; set; }
        public string PatientInsuranceInfo { get; set; }
        public string PatientPaymentMode { get; set; }

        // Emergency Contacts (List)
        public List<EmergencyContactViewModel> EmergencyContacts { get; set; } = new();

        // Referral Infos (List)
        public List<ReferralInfoViewModel> ReferralInfos { get; set; } = new();

        // Medical Record Fields
        public List<string> MedicalRecordCancerType { get; set; } = new();
        public string MedicalRecordCancerStage { get; set; }
        public string MedicalRecordComorbidities { get; set; }
        public string MedicalRecordTumorLocation { get; set; }
        public string MedicalRecordAllergies { get; set; }
        public string MedicalRecordClinicalHistory { get; set; }
       

        // Clinical Reports
        public List<ClinicalReportViewModel> ClinicalReports { get; set; } = new();

        // Board Approval
        public DateTime? BoardApprovalDate { get; set; }
        public bool? BoardApprovalDecision { get; set; }
        public string BoardApprovalLetterNumber { get; set; }
        public IFormFile BoardApprovalAttachment { get; set; }

        // Procedure
        public DateTime? ProcedureDate { get; set; }
        public string ProcedureDuration { get; set; }
        public string ProcedureROI { get; set; }
        public string ProcedureRemarks { get; set; }
    }

    public class EmergencyContactViewModel
    {
        public string Name { get; set; }
        public string CNIC { get; set; }
        public string Relationship { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
    }

    public class ReferralInfoViewModel
    {
        public string HospitalName { get; set; }
        public string City { get; set; }
        public string DoctorName { get; set; }
        public string Department { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }

    public class ClinicalReportViewModel
    {
        public string ReportType { get; set; }
        public IFormFile ReportFile { get; set; }
    }
}

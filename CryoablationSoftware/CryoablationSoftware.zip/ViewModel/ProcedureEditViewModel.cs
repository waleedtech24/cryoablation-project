﻿using System.ComponentModel.DataAnnotations;

namespace CryoablationSoftware.ViewModel
{
    public class ProcedureEditViewModel
    {
        public Guid ProcedureId { get; set; }

        [Required(ErrorMessage = "Please select a patient")]
        public Guid PatientId { get; set; }
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Procedure date is required")]
        public DateTime ProcedureDate { get; set; }

        [Required(ErrorMessage = "ROI (Region of Interest) is required")]
        [StringLength(200, ErrorMessage = "ROI cannot exceed 200 characters")]
        public string ProcedureROI { get; set; }

        [Required(ErrorMessage = "Duration is required")]
        [StringLength(50, ErrorMessage = "Duration cannot exceed 50 characters")]
        public string ProcedureDuration { get; set; }

        [StringLength(500, ErrorMessage = "Equipment details cannot exceed 500 characters")]
        public string? ProcedureEquipmentUsed { get; set; }

        [Required(ErrorMessage = "Remarks are required")]
        public string ProcedureRemarks { get; set; }

        [Required(ErrorMessage = "Status is required")]
        public string ProcedureStatus { get; set; }

        public DateTime? ProcedureNextDate { get; set; }

        public Guid? PreviousProcedureId { get; set; }

        public bool IsActive { get; set; }
    }
}

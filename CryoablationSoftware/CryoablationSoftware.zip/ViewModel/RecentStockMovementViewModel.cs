﻿namespace CryoablationSoftware.ViewModel
{
    public class RecentStockMovementViewModel
    {
        public DateTime Date { get; set; }
        public string ItemName { get; set; }
        public string MovementType { get; set; } // IN/OUT
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public string Reason { get; set; }
    }
}

﻿// ViewModels/Procedure/ProcedureCreateViewModel.cs - UPDATED
using System.ComponentModel.DataAnnotations;

namespace CryoablationSoftware.ViewModel
{
    public class ProcedureCreateViewModel
    {
        [Required(ErrorMessage = "Please select a patient")]
        public Guid PatientId { get; set; }
        public string? PatientName { get; set; } // For display

        [Required(ErrorMessage = "Procedure date is required")]
        public DateTime ProcedureDate { get; set; } = DateTime.Now.Date.AddDays(1).AddHours(9);

        [Required(ErrorMessage = "ROI (Region of Interest) is required")]
        [StringLength(200, ErrorMessage = "ROI cannot exceed 200 characters")]
        public string ProcedureROI { get; set; }

        [Required(ErrorMessage = "Duration is required")]
        [StringLength(50, ErrorMessage = "Duration cannot exceed 50 characters")]
        public string ProcedureDuration { get; set; }

        // FIXED: Made Equipment Optional
        [StringLength(500, ErrorMessage = "Equipment details cannot exceed 500 characters")]
        public string? ProcedureEquipmentUsed { get; set; }

        // FIXED: Made Remarks Optional
        public string? ProcedureRemarks { get; set; }

        public string ProcedureStatus { get; set; } = "Scheduled";

        public DateTime? ProcedureNextDate { get; set; }

        public Guid? PreviousProcedureId { get; set; }

        // Item Assignments
        public List<ProcedureItemAssignmentViewModel> ItemAssignments { get; set; } = new List<ProcedureItemAssignmentViewModel>();
    }

    
}
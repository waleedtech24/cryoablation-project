﻿namespace CryoablationSoftware.ViewModel
{
    public class ProcedureDetailsViewModel
    {
        public Guid ProcedureId { get; set; }
        public Guid PatientId { get; set; }
        public string PatientName { get; set; }
        public string PatientMRNumber { get; set; }

        public DateTime ProcedureDate { get; set; }
        public string ProcedureROI { get; set; }
        public string ProcedureDuration { get; set; }
        public string? ProcedureEquipmentUsed { get; set; }
        public string ProcedureRemarks { get; set; }
        public string ProcedureStatus { get; set; }
        public DateTime? ProcedureNextDate { get; set; }

        public string CreatedByName { get; set; }
        public DateTime CreatedAt { get; set; }

        // Item Details
        public List<ProcedureItemSummaryViewModel> ItemSummaries { get; set; } = new List<ProcedureItemSummaryViewModel>();

        // Clinical Reports
        public List<ProcedureClinicalReportViewModel> ClinicalReports { get; set; } = new List<ProcedureClinicalReportViewModel>();

        // Previous/Next Procedures
        public ProcedureBasicInfoViewModel? PreviousProcedure { get; set; }
        public ProcedureBasicInfoViewModel? NextProcedure { get; set; }
    }
}

﻿namespace CryoablationSoftware.ViewModel
{
    public class InventoryDashboardViewModel
    {
        public int TotalItems { get; set; }
        public int LowStockItems { get; set; }
        public int TotalSuppliers { get; set; }
        public decimal TotalInventoryValue { get; set; }

        public List<LowStockItemViewModel> LowStockAlerts { get; set; } = new List<LowStockItemViewModel>();
        public List<RecentStockMovementViewModel> RecentMovements { get; set; } = new List<RecentStockMovementViewModel>();

    }
}

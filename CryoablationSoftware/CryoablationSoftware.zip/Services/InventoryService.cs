﻿using CryoablationSoftware.Data;
using CryoablationSoftware.Models;
using CryoablationSoftware.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace CryoablationSoftware.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly ApplicationDbContext _context;

        public InventoryService(ApplicationDbContext context)
        {
            _context = context;
        }

        #region Item Management

        public async Task<IEnumerable<Item>> GetAllItemsAsync()
        {
            return await _context.Items
                .Where(i => i.IsActive)
                .Include(i => i.CreatedBy)
                .OrderBy(i => i.ItemName)
                .ToListAsync();
        }

        public async Task<Item> GetItemByIdAsync(Guid itemId)
        {
            return await _context.Items
                .Include(i => i.CreatedBy)
                .Include(i => i.StockRecords.Where(sr => sr.IsActive))
                .Include(i => i.UsageRecords.Where(ur => ur.IsActive))
                    .ThenInclude(ur => ur.Patient)
                .FirstOrDefaultAsync(i => i.ItemId == itemId && i.IsActive);
        }

        public async Task<bool> CreateItemAsync(ItemCreateViewModel model, string userId)
        {
            try
            {
                var item = new Item
                {
                    ItemId = Guid.NewGuid(),
                    ItemName = model.ItemName.Trim(),
                    ItemCode = model.ItemCode.Trim().ToUpper(),
                    Category = model.Category,
                    Unit = model.Unit,
                    ReorderLevel = model.ReorderLevel,
                    Description = model.Description?.Trim(),
                    CreatedById = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.Items.Add(item);
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> UpdateItemAsync(ItemEditViewModel model)
        {
            try
            {
                var item = await _context.Items.FindAsync(model.ItemId);
                if (item == null) return false;

                item.ItemName = model.ItemName.Trim();
                item.ItemCode = model.ItemCode.Trim().ToUpper();
                item.Category = model.Category;
                item.Unit = model.Unit;
                item.ReorderLevel = model.ReorderLevel;
                item.Description = model.Description?.Trim();
                item.IsActive = model.IsActive;

                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteItemAsync(Guid itemId)
        {
            try
            {
                var item = await _context.Items.FindAsync(itemId);
                if (item == null) return false;

                item.IsActive = false;
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> IsItemCodeUniqueAsync(string itemCode, Guid? excludeItemId = null)
        {
            var query = _context.Items.Where(i => i.ItemCode.ToUpper() == itemCode.ToUpper() && i.IsActive);

            if (excludeItemId.HasValue)
                query = query.Where(i => i.ItemId != excludeItemId.Value);

            return !await query.AnyAsync();
        }

        #endregion


  

        #region Stock Management

        public async Task<bool> ReceiveStockAsync(StockReceiveViewModel model, string userId)
        {
            try
            {
                var stockRecord = new StockRecord
                {
                    StockRecordId = Guid.NewGuid(),
                    ItemId = model.ItemId,
                    StockDate = model.StockDate,
                    QuantityReceived = model.QuantityReceived,
                    UnitCost = model.UnitCost,
                    TotalCost = model.QuantityReceived * model.UnitCost,
                    ExpiryDate = model.ExpiryDate,
                    BatchNumber = model.BatchNumber?.Trim(),
                 //   SupplierId = model.SupplierId,
                    Notes = model.Notes?.Trim(),
                    CreatedById = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.StockRecords.Add(stockRecord);
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> IssueStockAsync(StockIssueViewModel model, string userId)
        {
            try
            {
                // Check if sufficient stock available
                var currentStock = await GetCurrentStockAsync(model.ItemId);
                if (currentStock < model.QuantityUsed)
                    return false;

                var usageRecord = new UsageRecord
                {
                    UsageRecordId = Guid.NewGuid(),
                    ItemId = model.ItemId,
                    UsageDate = model.UsageDate,
                    QuantityUsed = model.QuantityUsed,
                    UsageReason = model.UsageReason,
                    PatientId = model.PatientId,
                    ProcedureId = model.ProcedureId,
                    Notes = model.Notes?.Trim(),
                    CreatedById = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.UsageRecords.Add(usageRecord);
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<int> GetCurrentStockAsync(Guid itemId)
        {
            var totalReceived = await _context.StockRecords
                .Where(sr => sr.ItemId == itemId && sr.IsActive)
                .SumAsync(sr => sr.QuantityReceived);

            var totalUsed = await _context.UsageRecords
                .Where(ur => ur.ItemId == itemId && ur.IsActive)
                .SumAsync(ur => ur.QuantityUsed);

            return totalReceived - totalUsed;
        }

        public async Task<IEnumerable<StockRecord>> GetStockHistoryAsync(Guid itemId)
        {
            return await _context.StockRecords
                .Where(sr => sr.ItemId == itemId && sr.IsActive)
                .Include(sr => sr.CreatedBy)
                .OrderByDescending(sr => sr.StockDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<UsageRecord>> GetUsageHistoryAsync(Guid itemId)
        {
            return await _context.UsageRecords
                .Where(ur => ur.ItemId == itemId && ur.IsActive)
                .Include(ur => ur.Patient)
                .Include(ur => ur.CreatedBy)
                .OrderByDescending(ur => ur.UsageDate)
                .ToListAsync();
        }

        #endregion

        #region Reports & Analytics

        public async Task<InventoryDashboardViewModel> GetDashboardDataAsync()
        {
            var totalItems = await _context.Items.CountAsync(i => i.IsActive);
          

            var lowStockItems = await GetLowStockItemsAsync();
            var lowStockCount = lowStockItems.Count();

            var totalValue = await _context.StockRecords
                .Where(sr => sr.IsActive)
                .SumAsync(sr => sr.TotalCost);

            var recentMovements = await GetRecentMovementsAsync();

            return new InventoryDashboardViewModel
            {
                TotalItems = totalItems,
                LowStockItems = lowStockCount,
             
                TotalInventoryValue = totalValue,
                LowStockAlerts = lowStockItems.ToList(),
                RecentMovements = recentMovements.ToList()
            };
        }

        public async Task<IEnumerable<ItemStockReportViewModel>> GetStockReportAsync()
        {
            var items = await _context.Items
                .Where(i => i.IsActive)
                .ToListAsync();

            var reportItems = new List<ItemStockReportViewModel>();

            foreach (var item in items)
            {
                //var currentStock = await GetCurrentStockAsync(item.ItemId);
                //var totalValue = await GetItemTotalValueAsync(item.ItemId);
                //var lastReceived = await GetLastReceivedDateAsync(item.ItemId);
                //var lastIssued = await GetLastIssuedDateAsync(item.ItemId);

                reportItems.Add(new ItemStockReportViewModel
                {
                    ItemId = item.ItemId,
                    ItemName = item.ItemName,
                    ItemCode = item.ItemCode,
                    Category = item.Category,
                    Unit = item.Unit,
                   // CurrentStock = currentStock,
                    ReorderLevel = item.ReorderLevel,
                  //  TotalValue = totalValue,
                 //   LastReceived = lastReceived,
                 //   LastIssued = lastIssued
                });
            }

            return reportItems.OrderBy(r => r.ItemName);
        }

        public async Task<IEnumerable<LowStockItemViewModel>> GetLowStockItemsAsync()
        {
            var items = await _context.Items
                .Where(i => i.IsActive && i.ReorderLevel > 0)
                .ToListAsync();

            var lowStockItems = new List<LowStockItemViewModel>();

            foreach (var item in items)
            {
                var currentStock = await GetCurrentStockAsync(item.ItemId);
                if (currentStock <= item.ReorderLevel)
                {
                    lowStockItems.Add(new LowStockItemViewModel
                    {
                        ItemId = item.ItemId,
                        ItemName = item.ItemName,
                        ItemCode = item.ItemCode,
                        CurrentStock = currentStock,
                        ReorderLevel = item.ReorderLevel,
                        Unit = item.Unit
                    });
                }
            }

            return lowStockItems.OrderBy(l => l.ItemName);
        }

        #endregion

        #region Utility Methods

        public async Task<IEnumerable<string>> GetCategoriesAsync()
        {
            return await _context.Items
                .Where(i => i.IsActive)
                .Select(i => i.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();
        }

        public async Task<IEnumerable<string>> GetUnitsAsync()
        {
            return await _context.Items
                .Where(i => i.IsActive)
                .Select(i => i.Unit)
                .Distinct()
                .OrderBy(u => u)
                .ToListAsync();
        }

        #endregion

        #region Private Helper Methods

        private async Task<IEnumerable<RecentStockMovementViewModel>> GetRecentMovementsAsync()
        {
            var recentIn = await _context.StockRecords
                .Where(sr => sr.IsActive)
                .Include(sr => sr.Item)
                .OrderByDescending(sr => sr.CreatedAt)
                .Take(5)
                .Select(sr => new RecentStockMovementViewModel
                {
                    Date = sr.StockDate,
                    ItemName = sr.Item.ItemName,
                    MovementType = "IN",
                    Quantity = sr.QuantityReceived,
                    Unit = sr.Item.Unit,
                    Reason = "Stock Received"
                })
                .ToListAsync();

            var recentOut = await _context.UsageRecords
                .Where(ur => ur.IsActive)
                .Include(ur => ur.Item)
                .OrderByDescending(ur => ur.CreatedAt)
                .Take(5)
                .Select(ur => new RecentStockMovementViewModel
                {
                    Date = ur.UsageDate,
                    ItemName = ur.Item.ItemName,
                    MovementType = "OUT",
                    Quantity = ur.QuantityUsed,
                    Unit = ur.Item.Unit,
                    Reason = ur.UsageReason
                })
                .ToListAsync();

            return recentIn.Concat(recentOut)
                .OrderByDescending(r => r.Date)
                .Take(10);
        }

        private async Task<decimal> GetItemTotalValueAsync(Guid itemId)
        {
            var currentStock = await GetCurrentStockAsync(itemId);
            if (currentStock <= 0) return 0;

            // Calculate weighted average cost
            var stockRecords = await _context.StockRecords
                .Where(sr => sr.ItemId == itemId && sr.IsActive)
                .OrderByDescending(sr => sr.StockDate)
                .ToListAsync();

            if (!stockRecords.Any()) return 0;

            var totalCost = stockRecords.Sum(sr => sr.TotalCost);
            var totalQuantity = stockRecords.Sum(sr => sr.QuantityReceived);

            if (totalQuantity == 0) return 0;

            var avgCost = totalCost / totalQuantity;
            return currentStock * avgCost;
        }

        private async Task<DateTime> GetLastReceivedDateAsync(Guid itemId)
        {
            var lastRecord = await _context.StockRecords
                .Where(sr => sr.ItemId == itemId && sr.IsActive)
                .OrderByDescending(sr => sr.StockDate)
                .FirstOrDefaultAsync();

            return lastRecord?.StockDate ?? DateTime.MinValue;
        }

        private async Task<DateTime> GetLastIssuedDateAsync(Guid itemId)
        {
            var lastRecord = await _context.UsageRecords
                .Where(ur => ur.ItemId == itemId && ur.IsActive)
                .OrderByDescending(ur => ur.UsageDate)
                .FirstOrDefaultAsync();

            return lastRecord?.UsageDate ?? DateTime.MinValue;
        }

        #endregion
    }
}

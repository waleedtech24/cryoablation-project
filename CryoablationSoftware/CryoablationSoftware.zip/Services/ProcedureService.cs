﻿using CryoablationSoftware.Data;
using CryoablationSoftware.Models;
using CryoablationSoftware.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace CryoablationSoftware.Services
{
    public class ProcedureService : IProcedureService
    {
        private readonly ApplicationDbContext _context;
        private readonly IInventoryService _inventoryService;

        public ProcedureService(ApplicationDbContext context, IInventoryService inventoryService)
        {
            _context = context;
            _inventoryService = inventoryService;
        }

        #region Procedure Management

        public async Task<IEnumerable<ProcedureListViewModel>> GetAllProceduresAsync()
        {
            return await _context.Procedures
                .Where(p => p.IsActive)
                .Include(p => p.Patient)
                .Include(p => p.CreatedBy)
                .Include(p => p.ItemAssignments.Where(ia => ia.IsActive))
                .Include(p => p.ItemUsages.Where(iu => iu.IsActive))
                .Select(p => new ProcedureListViewModel
                {
                    ProcedureId = p.ProcedureId,
                    PatientId = p.PatientId,
                    PatientName = p.Patient.PatientName,
                    PatientMRNumber = p.Patient.PatientMRNumber,
                    ProcedureDate = p.ProcedureDate,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureDuration = p.ProcedureDuration,
                    ProcedureStatus = p.ProcedureStatus,
                    TotalItemsAssigned = p.ItemAssignments.Sum(ia => ia.QuantityAssigned),
                    TotalItemsUsed = p.ItemUsages.Sum(iu => iu.QuantityUsed),
                    CreatedByName = p.CreatedBy.UserName,
                    CreatedAt = p.CreatedAt
                })
                .OrderByDescending(p => p.ProcedureDate)
                .ToListAsync();
        }

        public async Task<ProcedureDetailsViewModel> GetProcedureDetailsAsync(Guid procedureId)
        {
            var procedure = await _context.Procedures
                .Include(p => p.Patient)
                .Include(p => p.CreatedBy)
                .Include(p => p.ItemAssignments.Where(ia => ia.IsActive))
                    .ThenInclude(ia => ia.Item)
                .Include(p => p.ItemUsages.Where(iu => iu.IsActive))
                    .ThenInclude(iu => iu.Item)
                .Include(p => p.ClinicalReports.Where(cr => cr.IsActive))
                    .ThenInclude(cr => cr.ClinicalReport)
                .Include(p => p.ClinicalReports.Where(cr => cr.IsActive))
                    .ThenInclude(cr => cr.LinkedBy)
                .FirstOrDefaultAsync(p => p.ProcedureId == procedureId && p.IsActive);

            if (procedure == null) return null;

            var itemSummaries = await GetProcedureItemSummaryAsync(procedureId);

            // Get previous and next procedures
            var previousProcedure = await _context.Procedures
                .Where(p => p.PatientId == procedure.PatientId && p.ProcedureDate < procedure.ProcedureDate && p.IsActive)
                .OrderByDescending(p => p.ProcedureDate)
                .Select(p => new ProcedureBasicInfoViewModel
                {
                    ProcedureId = p.ProcedureId,
                    ProcedureDate = p.ProcedureDate,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureStatus = p.ProcedureStatus
                })
                .FirstOrDefaultAsync();

            var nextProcedure = await _context.Procedures
                .Where(p => p.PatientId == procedure.PatientId && p.ProcedureDate > procedure.ProcedureDate && p.IsActive)
                .OrderBy(p => p.ProcedureDate)
                .Select(p => new ProcedureBasicInfoViewModel
                {
                    ProcedureId = p.ProcedureId,
                    ProcedureDate = p.ProcedureDate,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureStatus = p.ProcedureStatus
                })
                .FirstOrDefaultAsync();

            return new ProcedureDetailsViewModel
            {
                ProcedureId = procedure.ProcedureId,
                PatientId = procedure.PatientId,
                PatientName = procedure.Patient.PatientName,
                PatientMRNumber = procedure.Patient.PatientMRNumber,
                ProcedureDate = procedure.ProcedureDate,
                ProcedureROI = procedure.ProcedureROI,
                ProcedureDuration = procedure.ProcedureDuration,
                ProcedureEquipmentUsed = procedure.ProcedureEquipmentUsed,
                ProcedureRemarks = procedure.ProcedureRemarks,
                ProcedureStatus = procedure.ProcedureStatus,
                ProcedureNextDate = procedure.ProcedureNextDate,
                CreatedByName = procedure.CreatedBy?.UserName,
                CreatedAt = procedure.CreatedAt,
                ItemSummaries = itemSummaries,
                ClinicalReports = procedure.ClinicalReports.Select(cr => new ProcedureClinicalReportViewModel
                {
                    ClinicalReportId = cr.ClinicalReportId,
                    ReportType = cr.ClinicalReport.ReportType,
                    ReportDescription = cr.ClinicalReport.ReportDescription,
                    ReportFilePath = cr.ClinicalReport.ReportFilePath,
                    ReportDate = cr.ClinicalReport.ReportDate,
                    LinkedAt = cr.LinkedAt,
                    LinkedByName = cr.LinkedBy?.UserName
                }).ToList(),
                PreviousProcedure = previousProcedure,
                NextProcedure = nextProcedure
            };
        }

        public async Task<Procedure> GetProcedureByIdAsync(Guid procedureId)
        {
            return await _context.Procedures
                .Include(p => p.Patient)
                .Include(p => p.CreatedBy)
                .FirstOrDefaultAsync(p => p.ProcedureId == procedureId && p.IsActive);
        }

        public async Task<bool> CreateProcedureAsync(ProcedureCreateViewModel model, string userId)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {

                var procedure = new Procedure
                {
                    ProcedureId = Guid.NewGuid(),
                    PatientId = model.PatientId,
                    ProcedureDate = model.ProcedureDate,
                    ProcedureROI = model.ProcedureROI.Trim(),
                    ProcedureDuration = model.ProcedureDuration.Trim(),
                //    ProcedureEquipmentUsed = model.ProcedureEquipmentUsed?.Trim(),
                    ProcedureRemarks = model.ProcedureRemarks.Trim(),
                    ProcedureStatus = model.ProcedureStatus,
                    ProcedureNextDate = model.ProcedureNextDate,
                    PreviousProcedureId = model.PreviousProcedureId,
                 
                    CreatedById = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.Procedures.Add(procedure);
                await _context.SaveChangesAsync();

                // Add item assignments if any
                if (model.ItemAssignments?.Any() == true)
                {
                    foreach (var itemAssignment in model.ItemAssignments.Where(ia => ia.QuantityAssigned > 0))
                    {
                        var assignment = new ProcedureItemAssignment
                        {
                            AssignmentId = Guid.NewGuid(),
                            ProcedureId = procedure.ProcedureId,
                            ItemId = itemAssignment.ItemId,
                            QuantityAssigned = itemAssignment.QuantityAssigned,
                            AssignmentReason = itemAssignment.AssignmentReason?.Trim(),
                            Notes = itemAssignment.Notes?.Trim(),
                            AssignedById = userId,
                            AssignedDate = DateTime.UtcNow,
                            IsActive = true
                        };

                        _context.ProcedureItemAssignments.Add(assignment);
                    }
                    await _context.SaveChangesAsync();
                }

                await transaction.CommitAsync();
                return true;
            }
            catch(Exception ex)
            {
                
                await transaction.RollbackAsync();
                return false;
            }
        }

        public async Task<bool> UpdateProcedureAsync(ProcedureEditViewModel model)
        {
            try
            {
                var procedure = await _context.Procedures.FindAsync(model.ProcedureId);
                if (procedure == null) return false;

                procedure.ProcedureDate = model.ProcedureDate;
                procedure.ProcedureROI = model.ProcedureROI.Trim();
                procedure.ProcedureDuration = model.ProcedureDuration.Trim();
                procedure.ProcedureEquipmentUsed = model.ProcedureEquipmentUsed?.Trim();
                procedure.ProcedureRemarks = model.ProcedureRemarks.Trim();
                procedure.ProcedureStatus = model.ProcedureStatus;
                procedure.ProcedureNextDate = model.ProcedureNextDate;
                procedure.PreviousProcedureId = model.PreviousProcedureId;
                procedure.IsActive = model.IsActive;

                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteProcedureAsync(Guid procedureId)
        {
            try
            {
                var procedure = await _context.Procedures.FindAsync(procedureId);
                if (procedure == null) return false;

                procedure.IsActive = false;
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region Item Assignment & Usage

        public async Task<bool> AssignItemToProcedureAsync(Guid procedureId, Guid itemId, int quantity, string reason, string? notes, string userId)
        {
            try
            {
                // Check if item already assigned
                var existingAssignment = await _context.ProcedureItemAssignments
                    .FirstOrDefaultAsync(pia => pia.ProcedureId == procedureId && pia.ItemId == itemId && pia.IsActive);

                if (existingAssignment != null)
                {
                    // Update existing assignment
                    existingAssignment.QuantityAssigned += quantity;
                    existingAssignment.Notes = notes?.Trim();
                }
                else
                {
                    // Create new assignment
                    var assignment = new ProcedureItemAssignment
                    {
                        AssignmentId = Guid.NewGuid(),
                        ProcedureId = procedureId,
                        ItemId = itemId,
                        QuantityAssigned = quantity,
                        AssignmentReason = reason.Trim(),
                        Notes = notes?.Trim(),
                        AssignedById = userId,
                        AssignedDate = DateTime.UtcNow,
                        IsActive = true
                    };

                    _context.ProcedureItemAssignments.Add(assignment);
                }

                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> RecordItemUsageAsync(ProcedureItemUsageViewModel model, string userId)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Validate usage against assignment
                var isValid = await ValidateItemUsageAsync(model.ProcedureId, model.ItemId, model.QuantityUsed);
                if (!isValid) return false;

                // Check inventory availability
                var currentStock = await _inventoryService.GetCurrentStockAsync(model.ItemId);
                if (currentStock < model.QuantityUsed) return false;

                // Record usage
                var usage = new ProcedureItemUsage
                {
                    UsageId = Guid.NewGuid(),
                    ProcedureId = model.ProcedureId,
                    ItemId = model.ItemId,
                    QuantityUsed = model.QuantityUsed,
                    UsageDateTime = model.UsageDateTime,
                    UsageNotes = model.UsageNotes?.Trim(),
                    RecordedById = userId,
                    RecordedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.ProcedureItemUsages.Add(usage);

                // Update inventory via existing inventory service
                var usageRecord = new UsageRecord
                {
                    UsageRecordId = Guid.NewGuid(),
                    ItemId = model.ItemId,
                    QuantityUsed = model.QuantityUsed,
                    UsageDate = model.UsageDateTime,
                    UsageReason = "Procedure",
                    ProcedureId = model.ProcedureId,
                    Notes = $"Used in procedure: {model.UsageNotes}",
                    CreatedById = userId,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.UsageRecords.Add(usageRecord);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();
                return true;
            }
            catch
            {
                await transaction.RollbackAsync();
                return false;
            }
        }

        public async Task<bool> RemoveItemAssignmentAsync(Guid assignmentId)
        {
            try
            {
                var assignment = await _context.ProcedureItemAssignments.FindAsync(assignmentId);
                if (assignment == null) return false;

                // Check if any usage recorded
                var hasUsage = await _context.ProcedureItemUsages
                    .AnyAsync(iu => iu.ProcedureId == assignment.ProcedureId && iu.ItemId == assignment.ItemId && iu.IsActive);

                if (hasUsage) return false; // Cannot remove assignment if items already used

                assignment.IsActive = false;
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<List<ProcedureItemSummaryViewModel>> GetProcedureItemSummaryAsync(Guid procedureId)
        {
            var assignments = await _context.ProcedureItemAssignments
                .Where(pia => pia.ProcedureId == procedureId && pia.IsActive)
                .Include(pia => pia.Item)
                .ToListAsync();

            var usages = await _context.ProcedureItemUsages
                .Where(piu => piu.ProcedureId == procedureId && piu.IsActive)
                .GroupBy(piu => piu.ItemId)
                .Select(g => new
                {
                    ItemId = g.Key,
                    TotalUsed = g.Sum(x => x.QuantityUsed),
                    LastUsageDate = g.Max(x => x.UsageDateTime)
                })
                .ToListAsync();

            return assignments.Select(a => new ProcedureItemSummaryViewModel
            {
                ItemId = a.ItemId,
                ItemName = a.Item.ItemName,
                ItemCode = a.Item.ItemCode,
                Unit = a.Item.Unit,
                QuantityAssigned = a.QuantityAssigned,
                QuantityUsed = usages.FirstOrDefault(u => u.ItemId == a.ItemId)?.TotalUsed ?? 0,
                AssignmentReason = a.AssignmentReason,
                AssignedDate = a.AssignedDate,
                LastUsageDate = usages.FirstOrDefault(u => u.ItemId == a.ItemId)?.LastUsageDate
            }).ToList();
        }

        #endregion

        #region Clinical Reports

        public async Task<bool> LinkClinicalReportAsync(Guid procedureId, Guid clinicalReportId, string userId)
        {
            try
            {
                // Check if already linked
                var existingLink = await _context.ProcedureClinicalReports
                    .FirstOrDefaultAsync(pcr => pcr.ProcedureId == procedureId && pcr.ClinicalReportId == clinicalReportId && pcr.IsActive);

                if (existingLink != null) return false; // Already linked

                var link = new ProcedureClinicalReport
                {
                    ProcedureClinicalReportId = Guid.NewGuid(),
                    ProcedureId = procedureId,
                    ClinicalReportId = clinicalReportId,
                    LinkedById = userId,
                    LinkedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.ProcedureClinicalReports.Add(link);
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> UnlinkClinicalReportAsync(Guid procedureId, Guid clinicalReportId)
        {
            try
            {
                var link = await _context.ProcedureClinicalReports
                    .FirstOrDefaultAsync(pcr => pcr.ProcedureId == procedureId && pcr.ClinicalReportId == clinicalReportId && pcr.IsActive);

                if (link == null) return false;

                link.IsActive = false;
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<List<AvailableClinicalReportViewModel>> GetAvailableClinicalReportsAsync(Guid patientId, Guid procedureId)
        {
            var linkedReports = await _context.ProcedureClinicalReports
                .Where(pcr => pcr.ProcedureId == procedureId && pcr.IsActive)
                .Select(pcr => pcr.ClinicalReportId)
                .ToListAsync();

            var reports = await _context.ClinicalReports
                .Where(cr => cr.MedicalRecord.PatientId == patientId && cr.IsActive)
                .Include(cr => cr.MedicalRecord)
                .Select(cr => new AvailableClinicalReportViewModel
                {
                    ClinicalReportId = cr.ClinicalReportId,
                    ReportType = cr.ReportType,
                    ReportDescription = cr.ReportDescription,
                    ReportDate = cr.ReportDate,
                    IsAlreadyLinked = linkedReports.Contains(cr.ClinicalReportId)
                })
                .OrderByDescending(cr => cr.ReportDate)
                .ToListAsync();

            return reports;
        }

        #endregion

        #region Dashboard & Analytics

        public async Task<ProcedureDashboardViewModel> GetDashboardDataAsync()
        {
            var totalProcedures = await _context.Procedures.CountAsync(p => p.IsActive);
            var scheduledProcedures = await _context.Procedures.CountAsync(p => p.IsActive && p.ProcedureStatus == "Scheduled");
            var inProgressProcedures = await _context.Procedures.CountAsync(p => p.IsActive && p.ProcedureStatus == "In-Progress");
            var completedProcedures = await _context.Procedures.CountAsync(p => p.IsActive && p.ProcedureStatus == "Completed");
            var cancelledProcedures = await _context.Procedures.CountAsync(p => p.IsActive && p.ProcedureStatus == "Cancelled");

            var upcomingProcedures = await _context.Procedures
                .Where(p => p.IsActive && p.ProcedureDate >= DateTime.Today && p.ProcedureStatus == "Scheduled")
                .Include(p => p.Patient)
                .OrderBy(p => p.ProcedureDate)
                .Take(5)
                .Select(p => new UpcomingProcedureViewModel
                {
                    ProcedureId = p.ProcedureId,
                    PatientName = p.Patient.PatientName,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureDate = p.ProcedureDate,
                    Status = p.ProcedureStatus
                })
                .ToListAsync();

            var recentProcedures = await _context.Procedures
                .Where(p => p.IsActive)
                .Include(p => p.Patient)
                .Include(p => p.ItemUsages.Where(iu => iu.IsActive))
                .OrderByDescending(p => p.ProcedureDate)
                .Take(5)
                .Select(p => new RecentProcedureViewModel
                {
                    ProcedureId = p.ProcedureId,
                    PatientName = p.Patient.PatientName,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureDate = p.ProcedureDate,
                    Status = p.ProcedureStatus,
                    TotalItemsUsed = p.ItemUsages.Sum(iu => iu.QuantityUsed)
                })
                .ToListAsync();

            var itemUsageSummary = await _context.ProcedureItemUsages
                .Where(piu => piu.IsActive && piu.UsageDateTime >= DateTime.Today.AddDays(-30))
                .Include(piu => piu.Item)
                .GroupBy(piu => new { piu.Item.ItemName, piu.Item.ItemCode, piu.Item.Unit })
                .Select(g => new ProcedureItemUsageSummaryViewModel
                {
                    ItemName = g.Key.ItemName,
                    ItemCode = g.Key.ItemCode,
                    Unit = g.Key.Unit,
                    TotalUsed = g.Sum(x => x.QuantityUsed),
                    ProcedureCount = g.Select(x => x.ProcedureId).Distinct().Count()
                })
                .OrderByDescending(x => x.TotalUsed)
                .Take(10)
                .ToListAsync();

            return new ProcedureDashboardViewModel
            {
                TotalProcedures = totalProcedures,
                ScheduledProcedures = scheduledProcedures,
                InProgressProcedures = inProgressProcedures,
                CompletedProcedures = completedProcedures,
                CancelledProcedures = cancelledProcedures,
                UpcomingProcedures = upcomingProcedures,
                RecentProcedures = recentProcedures,
                ItemUsageSummary = itemUsageSummary
            };
        }

        public async Task<IEnumerable<ProcedureListViewModel>> GetProceduresByPatientAsync(Guid patientId)
        {
            return await _context.Procedures
                .Where(p => p.PatientId == patientId && p.IsActive)
                .Include(p => p.Patient)
                .Include(p => p.CreatedBy)
                .Include(p => p.ItemAssignments.Where(ia => ia.IsActive))
                .Include(p => p.ItemUsages.Where(iu => iu.IsActive))
                .Select(p => new ProcedureListViewModel
                {
                    ProcedureId = p.ProcedureId,
                    PatientId = p.PatientId,
                    PatientName = p.Patient.PatientName,
                    PatientMRNumber = p.Patient.PatientMRNumber,
                    ProcedureDate = p.ProcedureDate,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureDuration = p.ProcedureDuration,
                    ProcedureStatus = p.ProcedureStatus,
                    TotalItemsAssigned = p.ItemAssignments.Sum(ia => ia.QuantityAssigned),
                    TotalItemsUsed = p.ItemUsages.Sum(iu => iu.QuantityUsed),
                    CreatedByName = p.CreatedBy.UserName,
                    CreatedAt = p.CreatedAt
                })
                .OrderByDescending(p => p.ProcedureDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<ProcedureListViewModel>> GetProceduresByStatusAsync(string status)
        {
            return await _context.Procedures
                .Where(p => p.ProcedureStatus == status && p.IsActive)
                .Include(p => p.Patient)
                .Include(p => p.CreatedBy)
                .Include(p => p.ItemAssignments.Where(ia => ia.IsActive))
                .Include(p => p.ItemUsages.Where(iu => iu.IsActive))
                .Select(p => new ProcedureListViewModel
                {
                    ProcedureId = p.ProcedureId,
                    PatientId = p.PatientId,
                    PatientName = p.Patient.PatientName,
                    PatientMRNumber = p.Patient.PatientMRNumber,
                    ProcedureDate = p.ProcedureDate,
                    ProcedureROI = p.ProcedureROI,
                    ProcedureDuration = p.ProcedureDuration,
                    ProcedureStatus = p.ProcedureStatus,
                    TotalItemsAssigned = p.ItemAssignments.Sum(ia => ia.QuantityAssigned),
                    TotalItemsUsed = p.ItemUsages.Sum(iu => iu.QuantityUsed),
                    CreatedByName = p.CreatedBy.UserName,
                    CreatedAt = p.CreatedAt
                })
                .OrderByDescending(p => p.ProcedureDate)
                .ToListAsync();
        }

        #endregion

        #region Utility Methods

        public async Task<IEnumerable<Patient>> GetActivePatientsAsync()
        {
            return await _context.Patients
                .Where(p => p.IsActive)
                .OrderBy(p => p.PatientName)
                .ToListAsync();
        }

        public async Task<IEnumerable<Item>> GetAvailableItemsAsync()
        {
            return await _context.Items
                .Where(i => i.IsActive)
                .OrderBy(i => i.ItemName)
                .ToListAsync();
        }

        public async Task<int> GetAvailableStockAsync(Guid itemId)
        {
            return await _inventoryService.GetCurrentStockAsync(itemId);
        }

        public async Task<bool> ValidateItemUsageAsync(Guid procedureId, Guid itemId, int quantityToUse)
        {
            var totalAssigned = await _context.ProcedureItemAssignments
                .Where(pia => pia.ProcedureId == procedureId && pia.ItemId == itemId && pia.IsActive)
                .SumAsync(pia => pia.QuantityAssigned);

            var totalUsed = await _context.ProcedureItemUsages
                .Where(piu => piu.ProcedureId == procedureId && piu.ItemId == itemId && piu.IsActive)
                .SumAsync(piu => piu.QuantityUsed);

            var remainingAssigned = totalAssigned - totalUsed;

            return quantityToUse <= remainingAssigned;
        }

        #endregion

        public async Task<bool> ChangeProcedureStatusAsync(Guid procedureId, string newStatus)
        {
            try
            {
                var procedure = await _context.Procedures.FindAsync(procedureId);
                if (procedure == null) return false;

                procedure.ProcedureStatus = newStatus;
                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> CompleteProcedureAsync(Guid procedureId, string irRemarks, DateTime? dischargeDate, DateTime? nextProcedureDate, string? completionNotes)
        {
            try
            {
                var procedure = await _context.Procedures.FindAsync(procedureId);
                if (procedure == null) return false;

                // Update procedure with completion details
                procedure.ProcedureStatus = "Completed";
                procedure.ProcedureNextDate = nextProcedureDate;

                // Append completion details to remarks
                var completionDetails = $"\n\n--- COMPLETION DETAILS ---\nIR Consultant Remarks: {irRemarks}\n";
                if (dischargeDate.HasValue)
                    completionDetails += $"Discharge Date: {dischargeDate.Value:dd/MM/yyyy}\n";
                if (!string.IsNullOrEmpty(completionNotes))
                    completionDetails += $"Completion Notes: {completionNotes}";

                procedure.ProcedureRemarks = (procedure.ProcedureRemarks ?? "") + completionDetails;

                await _context.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }


    }
}
